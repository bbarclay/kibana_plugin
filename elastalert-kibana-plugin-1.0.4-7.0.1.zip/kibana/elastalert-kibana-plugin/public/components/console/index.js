import { Console } from './console';
export { Console };
